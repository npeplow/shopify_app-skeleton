<?php

// Note: this prevents usage in MVC frameworks, which will be supported soon
//error_reporting(E_ALL & ~(E_NOTICE | E_WARNING | E_DEPRECATED));
//ini_set('display_errors', 1);
require __DIR__."/vendor/autoload.php";
session_start();