<?php

namespace CrudKit\Data;


abstract class BaseSQLDataProvider extends BaseDataProvider {

}